require 'csv'

class MySqliteRequest
    attr_accessor :table, :all_result, :new_all_result,:select_fields, :result_from,:path, :del_status, :update_status, :UpdateData
    
    def initialize(filename_db)
        @del_status = @update_status = 0
        @all_result = Array.new
        @select_fields=Array.new
        @result_from=Array.new
        @path = File.join(File.dirname(__FILE__), filename_db)
        @table = CSV.parse(File.read(@path), headers: true)
    end

    def from(table_name)
        @result_from=Array.new
        @table.each_with_object({}){ |hash1|  @result_from.push((Hash hash1).slice(*@select_fields))}
        self
    end

    def where(column_name, criteria)
        if @del_status == 1
            completeDelete(column_name, criteria)
        elsif @update_status ==1
            completeUpdate(column_name, criteria)
        else
            @new_all_result = Array.new
            if @all_result.length > 0
                @new_all_result = @all_result.select {|row| row[column_name].to_s ==criteria}.to_a
            else
                @new_all_result = @result_from.select {|row| row[column_name].to_s ==criteria}.to_a
            end
        end
        self
    end

    def order(order,column_name)
        if order == :asc
            @new_all_result = @new_all_result.sort_by {|row| row[column_name]}
        else
            @new_all_result = @new_all_result.sort_by {|row| row[column_name]}.reverse()
        end
        self
    end

    def select(*fields)
        @select_fields = fields.to_a
        self
    end

    def insert(data)
        new_data = data.map{|k, v| v}
        CSV.open(@path,"a") do |csv|
            csv << new_data
        end
        @new_all_result = [{"status" => "ok"}]
        self
    end
    #end of processing Delete
    def completeDelete(column_name, criteria)
        table = CSV.table(@path)
        table.delete_if do |row|
            row[column_name.to_sym] == criteria
        end
        File.open(@path, 'w') do |f|
            f.write(table.to_csv)
        end
        @new_all_result = [{"status" => "ok"}]
        self
    end

    def delete
        @del_status = 1
        self
    end
    #end of delete

    #processing - updates
    def completeUpdate(column_name, criteria)
        table = CSV.table(@path)
        table.each do |row|
            if row[column_name.to_sym]  == criteria
                @UpdateData.each{|k,v| row[k.to_sym] = v}
            end
        end

        File.open(@path, 'w') do |f|
            f.write(table.to_csv)
        end
        @new_all_result = [{"status" => "ok"}]
        self
    end

    def update(data)
        @update_status = 1
        @UpdateData = data
        self
    end
    #end updating here

    def join(column_on_db_a, filename_db_b, column_on_db_b)
        path = File.join(File.dirname(__FILE__), filename_db_b)
        tableb = CSV.parse(File.read(path), headers: true)
        @result_from.each_with_object({}){
            |hash1| 
            tableb.each_with_object({}) {
                    |hash2| 
                    hash1[column_on_db_a] == hash2[column_on_db_b] ? @all_result.push((Hash hash2).merge(Hash hash1).slice(*@select_fields)) : '' 
                }  
        }
        self
    end

    def run
        p @new_all_result
    end
    
end



def MySqliteRequest(file_name)
    return MySqliteRequest.new(file_name)
end

#MySqliteRequest("nba_player_data.csv").select("birth_city","birth_state","name").from("nba_player_data.csv").join("name","nba_player.csv","Player").where("birth_state","Indiana").run

#MySqliteRequest("nba_player_data.csv").select("name","year_start","year_end","height","college").from("nba_player_data.csv").where("college","Duke University").order(:desc, "height").run


# #run insert
# insVal = {"name"=>"Abudlraheem Sherif Adavuruku", "year_start"=> "2010", "year_end"=>"2019", "position"=>"A-10", "height"=>"215",
# "weight"=>"345", "birth_date"=>"January 10, 1992", "college"=>"Hamad Doley University"}
# MySqliteRequest("nba_player_data.csv").insert(insVal).run


# #name,year_start,year_end,position,height,weight,birth_date,college

# #run update
# insVal = {"name"=>"Muhammed John Osuwa", "year_start"=> "1945", "college"=>"Ahmadu Bello University"}
# MySqliteRequest("nba_player_data.csv").update(insVal).from("nba_player_data.csv").where("college","Hamad Doley University").run

#run search
MySqliteRequest("nba_player_data.csv").select("name","year_start","year_end","height","college").from("nba_player_data.csv").where("college","Ahmadu Bello University").order(:desc, "height").run

#run delete
MySqliteRequest("nba_player_data.csv").delete().from("nba_player_data.csv").where("college","Ahmadu Bello University").run